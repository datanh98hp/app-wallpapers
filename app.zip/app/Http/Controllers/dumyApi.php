<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dumyApi extends Controller
{
    //
    function getData(){
        return ["name"=>"DA"];
    }
}
